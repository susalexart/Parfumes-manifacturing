<?php
class ParfumManufacturingLine
{
    public $rowid,$fk_manufacturing,$fk_finished_product,$size_ml,$qty,$fk_packaging,$total_ml;
}
