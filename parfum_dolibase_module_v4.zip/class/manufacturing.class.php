<?php
class ParfumManufacturing
{
    public $db;
    public $id;
    public $fk_product;
    public $lines=array();
    public $total_batch_ml=0;
    public function __construct($db){$this->db=$db;}
    public function load($fk_manufacturing)
    {
        $res=$this->db->query('SELECT rowid,fk_finished_product,size_ml,qty,fk_packaging,total_ml FROM llx_parfum_manufacturing_lines WHERE fk_manufacturing='.intval($fk_manufacturing));
        $this->lines=array(); $this->total_batch_ml=0;
        while($obj=$this->db->fetch_object($res)){ $this->lines[]=$obj; $this->total_batch_ml+=$obj->total_ml; }
        $h=$this->db->query('SELECT fk_product FROM llx_parfum_manufacturing WHERE rowid='.intval($fk_manufacturing));
        $head=$this->db->fetch_object($h); $this->fk_product=$head->fk_product;
        return count($this->lines);
    }
    public function validate($fk_manufacturing,$user,$warehouse_id=1)
    {
        if(!$this->load($fk_manufacturing)) return -1;
        $form=new ParfumFormula($this->db); $form->fetchByProduct($this->fk_product);
        foreach($form->lines as $mat)
        {
            $required_ml=($mat->percentage>0)?($this->total_batch_ml*($mat->percentage/100.0)):$mat->qty_ml;
            $p=new Product($this->db); $p->fetch($mat->fk_material);
            $vol=(float)$p->array_options['options_volume_per_unit'];
            if($vol>0){$units=ceil($required_ml/$vol); $p->correct_stock(-$units,$warehouse_id,$user,'Manufacturing deduction');}
            else{$p->correct_stock(-ceil($required_ml),$warehouse_id,$user,'Manufacturing deduction');}
        }
        foreach($this->lines as $line)
        {
            if(!empty($line->fk_packaging)){$pack=new Product($this->db);$pack->fetch($line->fk_packaging);$pack->correct_stock(-$line->qty,$warehouse_id,$user,'Packaging for manufacturing');}
            $f=new Product($this->db); $f->fetch($line->fk_finished_product); $f->correct_stock($line->qty,$warehouse_id,$user,'Manufactured product');
        }
        $this->db->query('UPDATE llx_parfum_manufacturing SET status=2,total_batch_ml='.floatval($this->total_batch_ml).' WHERE rowid='.intval($fk_manufacturing));
        return 1;
    }
}
