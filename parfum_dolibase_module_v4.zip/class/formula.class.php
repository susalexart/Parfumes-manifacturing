<?php
class ParfumFormula
{
    public $db;
    public $lines = array();
    public function __construct($db) { $this->db=$db; }
    public function fetchByProduct($fk_product)
    {
        $this->lines=array();
        $res=$this->db->query('SELECT rowid,fk_material,percentage,qty_ml FROM llx_parfum_formula WHERE fk_product='.intval($fk_product));
        while($obj=$this->db->fetch_object($res)) $this->lines[]=$obj;
        return count($this->lines);
    }
}
