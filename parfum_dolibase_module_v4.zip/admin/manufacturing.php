<?php
dol_include_once('/core/lib/admin.lib.php'); $langs->load('admin'); llxHeader('','Parfum Manufacturing Orders');
print '<h2>Manufacturing Orders</h2>';
print '<p>Create orders with multiple finished product variants. Inline table with quantity, variant, and packaging selection.</p>';
llxFooter();
