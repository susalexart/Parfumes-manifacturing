<?php
dol_include_once('/core/lib/admin.lib.php'); $langs->load('admin'); llxHeader('','Parfum Formulas');
print '<h2>Formulas</h2>';
print '<p>Here you can add/edit formulas. Table with Add/Remove row buttons will appear here.</p>';
llxFooter();
