CREATE TABLE IF NOT EXISTS llx_parfum_manufacturing_lines (
  rowid INT AUTO_INCREMENT PRIMARY KEY,
  fk_manufacturing INT NOT NULL,
  fk_finished_product INT NOT NULL,
  size_ml DECIMAL(10,2) NOT NULL,
  qty INT NOT NULL,
  fk_packaging INT DEFAULT NULL,
  total_ml DECIMAL(24,6) GENERATED ALWAYS AS (size_ml * qty) STORED,
  entity INT DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
