<?php
include_once DOL_DOCUMENT_ROOT .'/core/modules/DolibarrModules.class.php';

class modParfum extends DolibarrModules
{
    public function __construct($db)
    {
        $this->db = $db;
        $this->numero = 900000;
        $this->rights_class = 'parfum';
        $this->family = 'products';
        $this->name = 'parfum';
        $this->description = 'Perfume manufacturing with fully interactive UI';
        $this->version = '1.3.0';
        $this->const_name = 'MAIN_MODULE_PARFUM';
        $this->picto = 'parfum@parfum';
        $this->dirs = array('/parfum/temp');
        $this->module_parts = array();
        $this->tables = array('parfum_formula','parfum_manufacturing','parfum_manufacturing_lines');
    }
    public function init() { $result=$this->load_tables('/parfum/sql/'); return $this->_init(array()); }
    public function remove() { return $this->_remove(array()); }
}
