# Parfum Manufacturing Module v4 (Fully Interactive UI)
Ready-to-install Dolibarr module for perfume manufacturing with fully interactive UI.

## Features
- Create/Edit/List Formulas with multiple materials (% or ml).
- Create/List/Validate Manufacturing Orders with multiple finished product variants.
- Deduct raw materials (ml) and packaging (units) automatically.
- Add finished product variants to stock automatically.
- Inline validation for % total and stock availability.
- Fully integrated menus under Products → Parfum Manufacturing.
- User-friendly: dropdowns, inline editable tables, Add/Remove row buttons.
